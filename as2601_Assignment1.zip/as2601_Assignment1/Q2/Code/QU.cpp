#include <fstream>
#include <iostream>
#include <time.h>
using namespace std;

class QuickUnionUF
{
private:
	int id[10000];

public:
	QuickUnionUF();
	int find(int p);
	bool connected(int p, int q);
	void f_union(int p, int q);

	
};

QuickUnionUF :: QuickUnionUF() // Function to initialise the array
{
	for (int i = 0; i < 10000; i++)
	{
		id[i] = i;
	}
}

int QuickUnionUF :: find(int i) // Function to find the root
{
	while (i !=id[i])
	
	i = id[i];

	return i;
	}

bool QuickUnionUF :: connected(int p, int q) //Fuction to check if the elements are connected
{
	if (find(p) == find(q))
	{
		return 1;
	}

	else

		return 0;

}

void QuickUnionUF :: f_union(int p, int q) // Function to union the elements
{
	int pid = find(p);
	int qid = find(q);
	id[pid] = qid;

	
}



int main()
{
	int p, q;
	QuickUnionUF obj;

	// Opening the required file in input mode.Please update the link while running in a different PC.
	char filename[100] = { "/home/ananth/Downloads/hw1-1.data/8192pair.txt" };

		ifstream fin;
		fin.open(filename);
		int ct = -1;
		fin >> p >> q;
		ct = ct + 1;
		clock_t start = clock();

		while (!fin.eof())
		{
			

			if (obj.connected(p, q))
			{
				fin >> p >> q;
				ct++;
			}
			else
			{
				obj.f_union(p, q);
				fin >> 	p >>	q;
				ct++;
			}

						
		}

		fin.close();
		cout << " Number of Pairs: " << ct <<endl;
		double duration = (double)(clock() - start) / CLOCKS_PER_SEC;
		cout << "The runtime is: " << duration << endl;
		ofstream fout;
		fout.open("/home/ananth/Downloads/hw1-1.data/out4.txt", ios::app);
		fout << ct << ',' << duration << endl;
		fout.close();
	
		return 0;


	}