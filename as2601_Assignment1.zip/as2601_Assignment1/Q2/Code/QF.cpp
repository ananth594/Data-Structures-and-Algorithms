#include <fstream>
#include <iostream>
#include <time.h>
using namespace std;

class QuickFindUF
{
private:
	int id[10000];

public:
	QuickFindUF();
	int find(int p);
	bool connected(int p, int q);
	void f_union(int p, int q);

	
};

QuickFindUF::QuickFindUF()   // Initialising all the elements of the array
{
	for (int i = 0; i < 10000; i++)
	{
		id[i] = i;
	}
}

int QuickFindUF:: find(int p) 	//  Assigning the ID of p to that of q
{
	int idq = id[p];
	return idq;

	}

bool QuickFindUF::connected(int p, int q) 	// loop to check the elements are connected
{
	if (find(p) == find(q))
	{
		return 1;
	}

	else

		return 0;

}

void QuickFindUF::f_union(int p, int q) // Union fuction if the elements are no yet connected
{
	int pid = id[p];
	int qid = id[q];

	for (int i = 0; i < 10000; i++)
	{
		if (id[i] == pid)
			id[i] = qid;
	}
}



int main()
{
	int p, q;
	QuickFindUF obj;
	// Reading the required file. Update the link while running on different PC.
	char filename[100] = { "/home/ananth/Downloads/hw1-1.data/8192pair.txt"};
							 

		ifstream fin;
		fin.open(filename);
			
		int ct = -1;
		fin >> p >> q;
		ct = ct + 1;
		clock_t start = clock();

		while (!fin.eof())
		{
			

			if (obj.connected(p, q))
			{
				fin >> p >> q;

				ct++;
			}
			else
			{
				obj.f_union(p, q);
				fin >> p >> q;
				ct++;
			}
			
		}
		fin.close();
		cout << " Number of integers: " << ct <<endl;
		double duration = (double)(clock() - start) / CLOCKS_PER_SEC;
		cout << "The runtime is: " << duration << endl;
		ofstream fout;
		fout.open("/home/ananth/Downloads/hw1-1.data/out3.txt", ios::app); // Saving the output to a text file.
		fout << ct << ',' << duration << endl;
		fout.close();
	
		return 0;


	}
