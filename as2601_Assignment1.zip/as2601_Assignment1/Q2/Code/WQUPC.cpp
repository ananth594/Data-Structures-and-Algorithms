#include <fstream>
#include <iostream>
#include <time.h>
using namespace std;

class WQuickUnionPC
{
private:
	int id[10000];
	int size[10000];

public:
	WQuickUnionPC();
	int find(int p);
	bool connected(int p, int q);
	void f_union(int p, int q);

	
};

WQuickUnionPC :: WQuickUnionPC()
{
	for (int i = 0; i < 10000; i++)
	{
		id[i] = i;
		size[i]=0;
	}
}

int WQuickUnionPC :: find(int i)
{
	while (i !=id[i])
	
	i = id[id[i]];

	return i;
	}

bool WQuickUnionPC :: connected(int p, int q)
{
	if (find(p) == find(q))
	{
		return 1;
	}

	else

		return 0;

}

void WQuickUnionPC :: f_union(int p, int q)
{
	int pid = find(p);
	int qid = find(q);
	//id[pid] = qid;
	if(size[p] < size [q])
	{
		id[pid]= qid;
		size[qid]=size[qid]+size[pid];
	}
	else
	{
		id[qid]=pid;
		size[pid] =size[pid]+size[qid];
	}
	

}



int main()
{
	int p, q;
	WQuickUnionPC obj;
	char filename[100] = {"/home/ananth/Downloads/hw1-1.data/8192pair.txt"};
	
		ifstream fin;
		fin.open(filename);
		int ct = -1;
		fin >> p >> q;
		ct = ct + 1;
		clock_t start = clock();

		while (!fin.eof())
		{
			

			if (obj.connected(p, q))
			{
				fin >> p >> q;
				ct++;
			}
			else
			{
				obj.f_union(p, q);
				fin >> 	p >>	q;
				ct++;
			}

						
		}

		fin.close();
		cout << " Number of Pairs: " << ct <<endl;
		double duration = (double)(clock() - start) / CLOCKS_PER_SEC;
		cout << "The runtime is: " << duration << endl;
		ofstream fout;
		fout.open("/home/ananth/Downloads/hw1-1.data/out6.txt", ios::app);
		fout << ct << ',' << duration << endl;
		fout.close();
	
		return 0;


	}