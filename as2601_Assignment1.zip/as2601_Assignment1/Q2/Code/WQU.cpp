#include <fstream>
#include <iostream>
#include <time.h>
using namespace std;

class WQuickUnionUF
{
private:
	int id[10000];
	int size[10000];

public:
	WQuickUnionUF();
	int find(int p);
	bool connected(int p, int q);
	void f_union(int p, int q);

	
};

WQuickUnionUF :: WQuickUnionUF() // Function to initialise the array
{
	for (int i = 0; i < 10000; i++)
	{
		id[i] = i;
		size[i]=0;
	}
}

int WQuickUnionUF :: find(int i) //Function to find the root
{
	while (i !=id[i])
	
	i = id[i];

	return i;
	}

bool WQuickUnionUF :: connected(int p, int q) // to check if the elements are connected
{
	if (find(p) == find(q))
	{
		return 1;
	}

	else

		return 0;

}

void WQuickUnionUF :: f_union(int p, int q)		// To union the elements
{
	int pid = find(p);
	int qid = find(q);
	//id[pid] = qid;
	if(size[p] < size [q])
	{
		id[pid]= qid;
		size[qid]=size[qid]+size[pid];
	}
	else
	{
		id[qid]=pid;
		size[pid] =size[pid]+size[qid];
	}
	

}



int main()
{
	int p, q;
	WQuickUnionUF obj;
	char filename[100] = {"/home/ananth/Downloads/hw1-1.data/8192pair.txt"};

		ifstream fin;
		fin.open(filename);
		int ct = -1;
		fin >> p >> q;
		ct = ct + 1;
		clock_t start = clock();

		while (!fin.eof())
		{
			

			if (obj.connected(p, q))
			{
				fin >> p >> q;
				ct++;
			}
			else
			{
				obj.f_union(p, q);
				fin >> 	p >>	q;
				ct++;
			}

						
		}

		fin.close();
		cout << " Number of Pairs: " << ct <<endl;
		double duration = (double)(clock() - start) / CLOCKS_PER_SEC;
		cout << "The runtime is: " << duration << endl;
		ofstream fout;
		fout.open("/home/ananth/Downloads/hw1-1.data/out5.txt", ios::app);
		fout << ct << ',' << duration << endl;
		fout.close();
	
		return 0;


	}