#include <iostream>
#include <stdio.h>
#include <fstream>
#include <time.h>
#include <algorithm>

using namespace std;

double count (int a[], int N)  // Function to calculate 3 sum
{
	int n = N;
	int total = 0;
	sort(a,a + n);
	double duration;

	clock_t start = clock();

	for (int i= 0; i< n ;i++)		
		for(int j=i+1;j < n;j++)
		{
			 int sum = a[i] + a[j];
			int num = (-1)*sum;

	int beg = 0;
	int end =n;
	while(beg <= end)					// Binary Search Implementation
	{
		int mid = (beg+end)/2;
		if(a[mid]==num)

		{
			
			break;
		}

		else if ( num > a[mid])

		{
			beg = mid+1;
		}

		else if( num < a[mid])

		{
			end =mid -1;
		}

		}
		
	

	 duration = (double)(clock()-start)/CLOCKS_PER_SEC; // Calculating the Duration
	

}
	cout<<"duration: "<<duration<<endl;
	return duration;
}

int main()
{	
	int num;
	int array1[10000];							// Initialising the base array
	int ct = -1;
	double run_time;
	ifstream fin,fin2,fin3,fin4,fin5,fin6,fin7,fin8;
	fin.open("/home/ananth/Downloads/hw1-1.data/8int.txt"); // Opening the required file in read mode.Please update the link for a different PC.
	cout << "file : 8int";
	int j = 0;
	while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	ofstream fout,fout2,fout3,fout4,fout5,fout6,fout7,fout8;
	fout.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::trunc); // Storing the output in a text file.
	fout<<ct<<','<<run_time<<endl;
	fout.close();

// Following the same procedure as above. Please Update the links while running on a different PC.
	ct = -1; 
	j=0;
	fin2.open("/home/ananth/Downloads/hw1-1.data/32int.txt");
	cout << "file : 32 int";
		while(!fin2.eof())
		{	
		
			fin2 >> array1[j++];
			ct++;
		}
	fin2.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout2.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout2<<ct<<','<<run_time<<endl;
	fout2.close();

	ct = -1; 
	j=0;
	fin3.open("/home/ananth/Downloads/hw1-1.data/128int.txt");
	cout << "file : 128 int";
		while(!fin3.eof())
		{	
		
			fin3 >> array1[j++];
			ct++;
		}
	fin3.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout3.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout3<<ct<<','<<run_time<<endl;
	fout3.close();

	ct = -1;
	j=0; 
	fin4.open("/home/ananth/Downloads/hw1-1.data/512int.txt");
	cout << "file : 512 int";
		while(!fin4.eof())
		{	
		
			fin4 >> array1[j++];
			ct++;
		}
	fin4.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout4.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout4<<ct<<','<<run_time<<endl;
	fout4.close();

	ct = -1; 
	j=0;
	fin5.open("/home/ananth/Downloads/hw1-1.data/1024int.txt");
	cout << "file : 1024 int";
		while(!fin5.eof())
		{	
		
			fin5 >> array1[j++];
			ct++;
		}
	fin5.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout5.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout5<<ct<<','<<run_time<<endl;
	fout5.close();

	ct = -1;
	j=0; 
	fin6.open("/home/ananth/Downloads/hw1-1.data/4096int.txt");
	cout << "file : 4096 int";
		while(!fin6.eof())
		{	
		
			fin6 >> array1[j++];
			ct++;
		}
	fin6.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout6.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout6<<ct<<','<<run_time<<endl;
	fout6.close();

	ct = -1;
	j=0; 
	fin7.open("/home/ananth/Downloads/hw1-1.data/4192int.txt");
	cout << "file : 4192 int";
		while(!fin7.eof())
		{	
		
			fin7 >> array1[j++];
			ct++;
		}
	fin7.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout7.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout7<<ct<<','<<run_time<<endl;
	fout7.close();

	ct = -1;
	j=0; 
	fin8.open("/home/ananth/Downloads/hw1-1.data/8192int.txt");
	cout << "file : 8192 int";
		while(!fin8.eof())
		{	
		
			fin8 >> array1[j++];
			ct++;
		}
	fin8.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout8.open("/home/ananth/Downloads/hw1-1.data/out2.txt",ios::app);
	fout8<<ct<<','<<run_time<<endl;
	fout8.close();

		return 0;
}
