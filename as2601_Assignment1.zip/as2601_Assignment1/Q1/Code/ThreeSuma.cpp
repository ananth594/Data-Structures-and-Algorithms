#include <iostream>
#include <stdio.h>
#include <fstream>
#include <time.h>

using namespace std;

double count (int a[], int N)							// Function to calculate the 3 Sum
{
	int n = N;
	int total = 0;
	clock_t start = clock();
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
			for (int k = j + 1; k < n; k++)
				if (a[i] + a[j] + a[k] == 0)
					total = total + 1;
				cout<<"The Number of 3 Sums in the text file are: "<<total<<endl;
	double duration = (double)(clock()-start)/CLOCKS_PER_SEC;
	cout<<"duration: "<<duration<<endl;

	return duration;
}

int main()
{
	int array1[10000];				// Initialising the base array
	int ct = -1;
	double run_time;
	ifstream fin;
	fin.open("/home/ananth/Downloads/hw1-1.data/8int.txt");  // Opening the required file in read mode
														     // Please update the above link while running on a different PC
	cout << "file : 8int";
	int j = 0;
	while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;											// Counter to calculate the number of characters in the file
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	ofstream fout;
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::trunc);		// Returning the time along with the count to a text file.
	fout<<ct<<','<<run_time<<endl;
	fout.close();

// Following the same procedure as above. Opening the different files.Please Update the links while running on a different PC.

	ct = -1; 
	fin.open("/home/ananth/Downloads/hw1-1.data/32int.txt");
	cout << "file : 32 int";
	j=0;
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();

	ct = -1; 
	fin.open("/home/ananth/Downloads/hw1-1.data/128int.txt");
	cout << "file : 128 int";
	j=0;
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();

	ct = -1; 
	fin.open("/home/ananth/Downloads/hw1-1.data/512int.txt");
	cout << "file : 512 int";
	j=0;
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();
	
	ct = -1; 
	fin.open("/home/ananth/Downloads/hw1-1.data/1024int.txt");
	j=0;
	cout << "file : 1024 int";
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();

	ct = -1; 
	j=0;
	fin.open("/home/ananth/Downloads/hw1-1.data/4096int.txt");
	cout << "file : 4096 int";
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();

	ct = -1; 
	j=0;
	fin.open("/home/ananth/Downloads/hw1-1.data/4192int.txt");
	cout << "file : 4192 int";
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();

	ct = -1;
	j=0; 
	fin.open("/home/ananth/Downloads/hw1-1.data/8192int.txt");
	cout << "file : 8192 int";
		while(!fin.eof())
		{	
		
			fin >> array1[j++];
			ct++;
		}
	fin.close();
	cout << " The Number of integers in the file are: " << ct<< endl;
	run_time= count(array1, ct);
	fout.open("/home/ananth/Downloads/hw1-1.data/out.txt",ios::app);
	fout<<ct<<','<<run_time<<endl;
	fout.close();

		return 0;
}
