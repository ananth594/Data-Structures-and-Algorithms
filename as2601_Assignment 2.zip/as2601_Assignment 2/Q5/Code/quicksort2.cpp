#include <iostream>
#include <fstream>
#include <algorithm>
#include <time.h>

using namespace std;

void swap(long int * a, long int *b)	//Function to swap the elements.
{

    long int t = *a;
    *a = *b;
    *b =t;
}


long int partition(long int a[],int lo,int hi)	// Function to partition the array.
{    
        
    
     int i = lo;
     int j = hi + 1;

    while(true)
    {
        while(a[++i]<a[lo])
        {

            if(i==hi)
            break;
        }
        
        while(a[lo]<a[--j])
        {

            if( j == lo)
            break;

        }
        
        if(i >= j)
        break;
        
        swap(&a[i],&a[j]);		//Swap the elements.
        
        
    }
    
    swap(&a[lo],&a[j]);			// Swap the partition element with the lowest element
    return j;    
        

        
 

}


void sort(long int a[], int lo , int hi, int &n_c)	//Function to sort the array
{
    int x = (hi - lo +1);
    cout << x << endl;

    int stacker[x];			// implementing a sack to sort the array
    int top = -1;

    stacker[++top] = lo;
    stacker[++top] = hi;

    while(top >= 0)
    {
    
        hi =  stacker[top--];
        lo =  stacker[top--];
    
        int p =  partition( a,lo,hi);	//Calling the partition function.
        
        if ( p-1 > lo)
        {
            stacker[++top]  =  lo;
            stacker[++top]  = p-1;
        }

    
        if( p+1 <hi)

        {

        stacker[++top] = p+1;
        stacker[++top] = hi;
        
        }

    }

}


int main()
{
    

    char filename[100] = { "/home/ananth/Downloads/hw2-dataset/ramdom1.txt" };	//Creating a text file to store the random numbers.

    const long int N = 1250000;		//Change this number to store the required number of elements in the array.
    static long int   a[N] = { 0 };
    static long int aux[N] = { 0 };
    int n_c = 0;
    
    
    srand (time(NULL));	
    
    ofstream fout1;
    fout1.open(filename);

    for(int k = 0;k<N ;k++)
    {

    a[k] = rand()%N + 1;		//Creating the required random numbers
    fout1<<a[k]<<endl;
        
    }

    random_shuffle(&a[0],&a[N-1]);	//Shuffle the array
    
    clock_t start = clock();
    sort(a, 0,N-1,n_c );		//Sort the array
    double duration = (double)(clock() - start)/CLOCKS_PER_SEC;

    char filename2[100] = { "/home/ananth/Downloads/hw2-dataset/routput2.txt"};
    ofstream fout2;
    fout2.open(filename2);
    

    for (int i = 0; i < N; i++)
    {
        fout2 << a[i]<<endl;	//Storing the sorted elements in an array
        
    }
    
    
    
    cout<<"The No. of Charaters in the file are : "<<N<<endl;
    cout<<"The Runtime is : "<< duration<<endl;
    

    return 0;
}


