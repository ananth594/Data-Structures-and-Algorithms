#include <iostream>
using namespace std;


int prefix(const char str[],const int first)	//Function to find the end of the prefix expression.
{
	int last = strlen(str) - 1;
	if (first < 0 || first > last)
		return -1;

	char ch = str[first];
	if ((ch >= 'a' && ch <= 'z') || (ch >= 'A'&& ch <= 'Z')) // Return first if the character read is an operand
		return first;

	else if (ch == '+' || '-' || '*' || '/') //Check if the input character is an operator
	{
		int first_end = prefix(str, first + 1);	//Recursively call the function to find the first end.

		if (first_end > -1)
			return prefix(str, first_end + 1);	// Recursively call the function in case first-end is greater than -1.

		else 
			return -1;
	}
	else
		return -1;
}


int main()
{
	char str[100];	//Array to store the string
	int first = 0;
	int end = 0;

	cout << "Enter the Pre-Fix Expression : " << endl;	//Read in the input expression from the user.
	cin >> str;

	end = prefix(str, first);							// the function returns the end of the prefix expression.
	cout << "The end is : " << end <<endl;
	return 0;
	
}