
#include<iostream>
#include <fstream>
#include<list>
#include <stack>

using namespace std;

int flag =0;
char Array[100];
int Destination; 
int id[100];
int G_size;


class Graph						//Class graph declaration
{
    int V;    						// No. of vertices
    list<int> *adj;    					// Pointer to an array containing adjacency lists
    void DFSU(int v, bool visited[]); 		 
public:
    Graph(int V);   					
    void addEdge(int v, int w);   	
    void DFS(int v);    
};
 
Graph::Graph(int V)
{
    this->V = V;
    adj = new list<int>[V];
}
 
void Graph::addEdge(int v, int w)		// Function to add an edge to the 
{
    adj[v].push_back(w); 
}
 
void Graph::DFSU(int s, bool visited[])
{
       						// Create a stack for DFS
    stack<int> stack;
    stack.push(s);
 
    while (!stack.empty())
    {
       						 // Pop the top of the stack and print it.
        s = stack.top();
        stack.pop();
 
       if(s == Destination){
            cout<<endl << " Possible to reach the destination. " <<endl;
            flag = 1;
            return;
    }
         
        
        if (!visited[s])			// To tackle multiple city occurances
        {
            cout << Array[s] << " ";
            visited[s] = true;
        }
 
    list<int>::iterator i;
    for (i = adj[s].begin(); i != adj[s].end(); ++i)
        if (!visited[*i])
            stack.push(*i);
    }
}
 
void Graph::DFS(int v)
{
    
    bool *visited = new bool[V];					//Marking all nodes visited
    for (int i = 0; i < V; i++)
        visited[i] = false;
     DFSU(v, visited);
     if(flag ==0){
     cout<<endl<<"No route Exists between the two cities given"<<endl;
     }
}
 
int main()
{
   						 
    char c1, c2;
    ifstream fin;
    fin.open("Cities.txt");				//File containing all the cities
    fin >> G_size;
    Graph g(G_size);
    cout<<"The size of the Graph is : "<< G_size <<endl;
    
    int i =0;
    while (!fin.eof())
    {   
        
        fin>>Array[i];
        id[Array[i]] = i;
        i++;
    }
    fin.close();

    ifstream fin1;
    fin1.open("CityConnections.txt");			//File containing how the cities are connected

    while (fin1 >> c1 >> c2)
    {
        g.addEdge(id[c1], id[c2]);
    }
    fin1.close();

    

    ifstream fin2;
    fin2.open("CheckConnection.txt");			//File containing which two need to be checked if they are connected

    while (fin2 >> c1 >> c2)
    {    
    Destination = id[c2];
    g.DFS(id[c1]);
    }
    fin2.close(); 
    return 0;
    }
