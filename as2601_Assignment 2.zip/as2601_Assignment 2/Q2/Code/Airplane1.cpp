
#include<iostream>
#include <fstream>
#include<list>

using namespace std;

int flag =0;
char Array[100];
int Destination; 
int id[100];
int G_size;


class Graph						//Class graph declaration
{
    int V;    						// No. of vertices
    list<int> *adj;    					// Pointer to an array containing adjacency lists
    void DFSU(int v, bool visited[]); 		 
public:
    Graph(int V);   					
    void addEdge(int v, int w);   	
    void DFS(int v);    
};
 
Graph::Graph(int V)
{
    this->V = V;
    adj = new list<int>[V];
}
 
void Graph::addEdge(int v, int w)		// Function to add an edge to the 
{
    adj[v].push_back(w); 
}
 
void Graph::DFSU(int v, bool visited[])
{
    if(flag ==0){
    visited[v] = true;				//Marking visited nodes as visited.
    cout<<endl<<"At point: "<<Array[v]<<endl;
            if(v == Destination){
            cout<<endl<< "At Destination" <<endl;
            flag = 1;
            return;
    }
 
    
       list<int>::iterator i;
    for (i = adj[v].begin(); i != adj[v].end(); ++i)
        if (!visited[*i])
            DFSU(*i, visited);
    }
}
 
void Graph::DFS(int v)
{
    						// Marking all the vertices as not visited
    bool *visited = new bool[V];
    for (int i = 0; i < V; i++)
        visited[i] = false;
        						
    DFSU(v, visited);
    
}
 
int main()
{
   						 
    char c1, c2;
    ifstream fin;
    fin.open("Cities.txt");				//File containing all the cities
    fin >> G_size;
    Graph g(G_size);
    cout<<"The size of the Graph is : "<< G_size <<endl;
    
    int i =0;
    while (!fin.eof())
    {   
        
        fin>>Array[i];
        id[Array[i]] = i;
        i++;
    }
    fin.close();

    ifstream fin1;
    fin1.open("CityConnections.txt");			//File containing how the cities are connected

    while (fin1 >> c1 >> c2)
    {
        g.addEdge(id[c1], id[c2]);
    }
    fin1.close();

    

    ifstream fin2;
    fin2.open("CheckConnection.txt");			//File containing which two need to be checked if they are connected

    while (fin2 >> c1 >> c2)
    {    
    Destination = id[c2];
    g.DFS(id[c1]);
    }
    fin2.close(); 
    return 0;
    }
