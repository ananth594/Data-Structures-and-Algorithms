#include <iostream>
#include <fstream>
using namespace std;


void merge(long int a[], int lo, int mid, int hi,int &n_c)	//Function to merge the arrays.
{	
		
	long int aux[40000];

	for (int k = lo; k <= hi; k++)
		aux[k] = a[k];
	
	int i = lo;
	int j = mid + 1;

	for (int k = lo; k <= hi; k++)		//Different conditions considered to decide which element to store first in the merged array
	{
		if (i > mid)
			a[k] = aux[j++];

		else if (j > hi)
			a[k] = aux[i++];

		else if (aux[j] < aux[i])
			a[k] = aux[j++];

		else
			a[k] = aux[i++];
		
		n_c = n_c + 1;			//To determine the number of comparisons.

	}

 

}


void sort(long int a[], int lo , int hi, int &n_c)		//Function to sort the array
{
	if (lo<hi)
	{
	
	int mid = lo + (hi - lo) / 2;
	sort(a,lo, mid,n_c);
	sort(a,mid + 1, hi, n_c);
	merge(a,lo, mid, hi, n_c);
	
	}	

}


int main()
{
	
	char filename[100] = { "/home/ananth/Downloads/hw2-dataset/data1.1024" }; //Reading the required file

	int count = 0;
	long int   a[40000] = { 0 };
	long int aux[40000] = { 0 };
	int n_c =0;
	

	ifstream fin;
	fin.open(filename);

        int i = 0; 
	while(!fin.eof())
	{

		int n;
		fin >> n;
		a[i] = n;
		count++;
		i++;

	}
	
	sort(a, 0, count-1,n_c );	//Calling the sorting function
	char filename2[100] = { "/home/ananth/Downloads/hw2-dataset/output0.txt" };
	ofstream fout;
	fout.open(filename2);

	for (int i = 0; i < count; i++)
	{
		fout << a[i]<<endl;	//Storing the sorted array in a text file.
		
	}
	
	fout << "No. of Comparisons :"<<n_c;

	cout<<"The No. of Charaters in the file are : "<< count-1 <<endl;
	cout<<"The No. of Comparisons are : "<<n_c <<endl;

	return 0;
}
