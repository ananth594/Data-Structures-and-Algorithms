#include <iostream>
#include <fstream>
using namespace std;


void merge(long int a[],long int aux[], int lo, int mid, int hi,int &n_c)	//Function to merge the arrays
{	
		
	
	for (int k = lo; k <= hi; k++)
		aux[k] = a[k];
	
	int i = lo;
	int j = mid + 1;

	for (int k = lo; k <= hi; k++)		//Different conditions considered to decide which element to store first in the merged array
	{
		if (i > mid)
			a[k] = aux[j++];

		else if (j > hi)
			a[k] = aux[i++];

		else if (aux[j] < aux[i])
			a[k] = aux[j++];

		else
			a[k] = aux[i++];
		
		n_c = n_c + 1;

	}

 

}


void sort(long int a[],int count, int &n_c)	// Function to sort the array.
{
	int N = count;
	long int aux[40000] ={0};
	for(int sz = 1; sz<N; sz= sz+sz)	//Implementing bottom up merge sort to sort the given array.
	for(int lo =0;lo<N-sz; lo= lo+sz+sz)
	{
	if((lo+sz+sz-1)<(N-1))
	merge(a,aux,lo,lo+sz-1,lo+sz+sz-1,n_c);
	else
	merge(a,aux,lo,lo+sz-1,N-1,n_c);
	}	

}


int main()
{
	
	char filename[100] = { "/home/ananth/Downloads/hw2-dataset/data1.32768" }; //Reading the required input file.

	int count = 0;
	long int   a[40000] = { 0 };
	long int aux[40000] = { 0 };
	int n_c =0;
	

	ifstream fin;
	fin.open(filename);

        int i = 0; 
	while(!fin.eof())	//Storing the elements in an array.
	{

		int n;
		fin >> n;
		a[i] = n;
		count++;
		i++;

	}
	
	sort(a,count,n_c );	//Calling the sort funcion to sort the array.
	char filename2[100] = { "/home/ananth/Downloads/hw2-dataset/output1.txt" };	//Creating  a file to store the sorted elements
	ofstream fout;
	fout.open(filename2);

	for (int i = 0; i < count; i++)
	{
		fout << a[i]<<endl;
		
	}
	
	fout << "No. of Comparisons :"<<n_c;

	cout<<"The No. of Charaters in the file are : "<< count-1 <<endl;
	cout<<"The No. of Comparisons are : "<<n_c <<endl;

	return 0;
}
