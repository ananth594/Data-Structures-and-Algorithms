#include<bits/stdc++.h>
#include<iostream>
#include<list>
#include<fstream>
#include <string>
#include <sstream>
 
using namespace std;

typedef pair<int,float> wvPair;   

class Graph
{
    int V;    
    list<wvPair> *adj;    
public:
    Graph(int V);  
    void addEdge(int u,int v, float wt); 
    void BFS(int s);  
};
 
Graph::Graph(int V)			//Constructor
{
    this->V = V;
    adj = new list<wvPair>[V];
}
 
void Graph::addEdge(int u,int v,float w)	// Function to add an Edge
{
    adj[u].push_back(make_pair(v,w)); 
}
 
void Graph::BFS(int s)			// Implementation of Bredth First Search
{
	int start =s;
    
    bool *visited = new bool[V];
    for(int i = 0; i < V; i++)
        visited[i] = false;
 float weight;
    
    list< pair<int,float> > queue;
 
    
    visited[s] = true;
    queue.push_back(make_pair(s,-1));
 
    
    list< pair<int,float> >::iterator i;
 	
        int j=0;
	int EdgeTo;	
    while(!queue.empty())
    {
        
        s = queue.front().first;
	

        queue.pop_front();
 
        
        for(i = adj[s].begin(); i != adj[s].end(); ++i)
        {
            if(!visited[(*i).first])
            {   
                visited[(*i).first] = true;
		weight=(*i).second;
		EdgeTo=s;
	        if(j < 50)
				{
					cout << " " << (*i).first << " \t\t 	" << s <<" \t\t 	"<< weight<< endl;
					
				}
			

	
                queue.push_back(make_pair((*i).first,(*i).second));
		j++;
            }
        }
    }

}
int main()
{
   
        ifstream fin;
	fin.open("HW5-NYC.txt");

	stringstream strstrm;
	string line;
	int Vertices;
	int edges;
	if (fin.is_open())
	{
		getline(fin, line);
		strstrm << line;
		strstrm >> Vertices;
		strstrm.str("");
		strstrm.clear();
		

		getline(fin, line);
		strstrm << line;
		strstrm>>edges;
		strstrm.str("");
		strstrm.clear();
		

		Graph G(300962);
		int v, w;
		float dist;
		
		while (!fin.eof())
		{
			
			getline(fin, line);
			strstrm << line;
			strstrm >> v >> w >> dist;
			
			G.addEdge(v, w,dist);
			strstrm.str("");
			strstrm.clear();
		}


		cout << "\n" << "Vertices" << "\t\t 	" << "EdgeTo" << "\t\t 	" << "DistanceTo" << endl;
		G.BFS (0);
		
	}

	fin.close();

    return 0;
}



