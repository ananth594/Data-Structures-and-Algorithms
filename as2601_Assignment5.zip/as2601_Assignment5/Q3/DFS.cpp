
#include<iostream>
#include<list>
#include<fstream>
#include <string>
#include <sstream>
 
using namespace std;
typedef pair<int,float> wvPair; 

class Graph
{
    int V;    
    list<wvPair> *adj;    
    void DFSUtil(int v, bool visited[]); 

public:

    Graph(int V);   
    void addEdge(int u, int v,float wt);  
    void DFS(int v);    
};
 
Graph::Graph(int V)
{
    this->V = V;
    adj = new list<wvPair>[V];
}
 
void Graph::addEdge(int u, int v,float wt)	//Function to add an Edge
{
    
    adj[u].push_back(make_pair(v,wt)); 
}
 int j=0; 

void Graph::DFSUtil(int v, bool visited[])	//Utility Function for DFS
{	
	
	int toEdge;
	float weight;
    
    	visited[v] = true;
	j++;
   
	 list<wvPair>::iterator i;
    for (i = adj[v].begin(); i != adj[v].end(); i++)
       { 
	if (!visited[(*i).first])

           {    weight=(*i).second;
		 if (j < 50)
            	{
                	cout << " " << (*i).first << " \t\t     " << v <<" \t\t     "<< weight<<endl;

            	}
		else
			break;
		
		DFSUtil((*i).first, visited);
		   
		
		}	

	}
}
 

void Graph::DFS(int v)
{
   
    bool *visited = new bool[V];
    for (int i = 0; i < V; i++)
        visited[i] = false;
 
    
    DFSUtil(v, visited);
}
 
int main()
{
   
 	ifstream fin;
	fin.open("HW5-NYC.txt");

	stringstream ss;
	string line;

	int Vertices;
	int edges;

	if (fin.is_open())
	{
		getline(fin, line);
		ss << line;
		ss >> Vertices;
		ss.str("");
		ss.clear();
		
		getline(fin, line);
		ss << line;
		ss>>edges;
		ss.str("");
		ss.clear();
		

		Graph G(300962);
		int v, w;
		float dist;
		
		while (!fin.eof())
		{
			
			getline(fin, line);
			ss << line;
			ss >> v >> w >> dist;
			
			G.addEdge(v, w,dist);
			ss.str("");
			ss.clear();
		}


		cout << "\n" << "Vertices" << "\t\t 	" << "EdgeTo" << "\t\t 	" << "DistanceTo" << endl;
		G.DFS (2);
		
	}
	fin.close();

    return 0;
}
