#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<fstream>
#include<iostream>

using namespace std;


struct Edge			// Structure for the Edge of the graph
{
	int src, dest;
	float weight;
};

struct Graph			// Stucture for the Graph
{
	
	int V, E;
	struct Edge* edge;
};



struct Graph* createGraph(int V, int E)		//Initialising the Graph
{
	struct Graph* graph = (struct Graph*) malloc(sizeof(struct Graph));
	graph->V = V;
	graph->E = E;

	graph->edge = (struct Edge*) malloc(graph->E * sizeof(struct Edge));

	return graph;
}



struct subset
{
	int parent;
	int rank;
};




int find(struct subset subsets[], int i)	//Find the subsets in the Graph
{
	
	if (subsets[i].parent != i)
		subsets[i].parent = find(subsets, subsets[i].parent);

	return subsets[i].parent;
}



void Union(struct subset subsets[], int x, int y)
{
	int xroot = find(subsets, x);
	int yroot = find(subsets, y);

	
	if (subsets[xroot].rank < subsets[yroot].rank)
		subsets[xroot].parent = yroot;
	else if (subsets[xroot].rank > subsets[yroot].rank)
		subsets[yroot].parent = xroot;

	
	else
	{
		subsets[yroot].parent = xroot;
		subsets[xroot].rank++;
	}
}


int myComp(const void* a, const void* b)		//comparison fuction for q sort
{
	struct Edge* a1 = (struct Edge*)a;
	struct Edge* b1 = (struct Edge*)b;
	return a1->weight > b1->weight;
}



void KruskalMST(struct Graph* graph)			// Function to compute the MST of the graph
{
	int V = graph->V;
	struct Edge result[10000];  
	int e = 0;  
	int i = 0;  
				
	qsort(graph->edge, graph->E, sizeof(graph->edge[0]), myComp);

	
	struct subset *subsets =
		(struct subset*) malloc(V * sizeof(struct subset));

	
	for (int v = 0; v < V; ++v)
	{
		subsets[v].parent = v;
		subsets[v].rank = 0;
	}

	
	while (e < V - 1)
	{
		
		struct Edge next_edge = graph->edge[i++];

		int x = find(subsets, next_edge.src);
		int y = find(subsets, next_edge.dest);

		
		if (x != y)
		{
			result[e++] = next_edge;
			Union(subsets, x, y);
		}
		
	}

	
	printf("The edges in the constructed MST are as follows:\n");
	for (i = 0; i < e; ++i)
		printf("%d -- %d == %f \n", result[i].src, result[i].dest,
			result[i].weight);
	return;
}


int main()		//Main Function
{

	int V,E;   	
	int v, w;
	float weight1;
	int i = 0;

	ifstream fin;
	fin.open("HW5-mediumEWG.txt"); 
	fin >> V;
	fin >> E;

	struct Graph* graph = createGraph(V, E);

	while (fin >> v >> w >> weight1)
	{
		
		graph->edge[i].src = v;
		graph->edge[i].dest = w;
		graph->edge[i].weight = weight1;
		i++;

	}

	fin.close();

	KruskalMST(graph);

	return 0;
}
