// Name: Ananth Sankarasubramanian
// Course: Data Structures and Algorithms
// Homework 5 A
// Date : 04/25/2017



#include<iostream>
#include <list>
#include <limits.h>
#include <fstream>

using namespace std;

class Graph		
{

public:
	Graph(int V);   
	void addEdge(int v, int w);
	bool isCyclic();

private:

	int V;    
	list<int> *adj;    
	bool isCyclicu(int v, bool visited[], bool *rs); 


};


Graph::Graph(int V)	// Constructor
{
	this->V = V;
	adj = new list<int>[V];
}


void Graph::addEdge(int v, int w)	// FUnction to add an Edge
{
	adj[v].push_back(w); 
}



bool Graph::isCyclicu(int v, bool visited[], bool *recStack)	// Utility function for iscyclic
{
	if (visited[v] == false)
	{
		
		visited[v] = true;
		recStack[v] = true;

		list<int>::iterator i;
		for (i = adj[v].begin(); i != adj[v].end(); ++i)
		{
			if (!visited[*i] && isCyclicu(*i, visited, recStack))
				return true;
			else if (recStack[*i])
				return true;
		}

	}
	recStack[v] = false;  
	return false;
}


bool Graph::isCyclic()	//Function to find if the function is Acyclic or not 
{
	bool *recStack = new bool[V];
	bool *visited = new bool[V];
	
	for (int i = 0; i < V; i++)
	{
		visited[i] = false;
		recStack[i] = false;
	}

	
	for (int i = 0; i < V; i++)
		if (isCyclicu(i, visited, recStack))
			return true;

	return false;
}

int main()	//Main Function
{
	
	
	ifstream fin("Text.txt", ios::in);
	int tot_v, tot_e;
	fin >> tot_v >> tot_e;
	Graph g(tot_v);
	int v, w;
	double weight;
	while (!fin.eof())
	{
		fin >> v >> w >> weight;
		cout << v <<"\t"<< w <<"\t"<< weight <<"\t"<< endl;
		g.addEdge(v, w);
	}
	
	if (g.isCyclic())
		cout << "Graph is cyclic"<<endl;
	else
		cout << "Graph is acyclic"<<endl;
	return 0;
}