
#include<string>
#include "23tree.h"


int main(int argc, char** argv) 
{
		char ch;
	

		int str;
		tree23 t;
		do{

		cout << "Enter the number to be inserted to be inserted into the tree:" << endl;
		cin >> str;
		t.insert(str);
		cout << "Do you want to continue building the tree (y/n)?" << endl;
		
		cin >> ch;

		} 
		while (ch == 'y' || ch == 'Y');

		t.PrintTree();

		
		return 0;
				
	
}
	