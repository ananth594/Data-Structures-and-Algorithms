
#include<iostream>
#include<assert.h>

using namespace std;
struct Node {
	int leftData;
	int rightData;
	short value;
	Node *left;      // left subtree
	Node *middle;    // middle subtree
	Node *right;     // right subtree
	Node *parent;    // parent (may not need)
};
class tree23 {
	Node *root;
	Node* init(int); //create a new node
	Node* splitNode(Node*, Node*, int); //split node
	void helperFunc(Node *, int);	      //helper function for inserting
	int* promote(int, int, int);		
	void insertSecondItem(Node*, int);  //insert a new item to a 2 node
	bool isLeaf(Node*);				   //check if the node is leaf
	int childPosition(Node*, Node*);  //check if a node is parent's left, middle, or right child
	void printNode(Node*);           //print a node's value
	

public:
	int treeHeight = 0;
	tree23() 
	{ 
		root = NULL; 
	};
	void insert(int);						 // insert an item
	int PrintTree();						// display the tree
};

