#include<iostream>
#include<fstream>

using namespace std;

int r_rot = 0;
int l_rot = 0;
int n_splits = 0;
int n_ins = 0;


struct node
{
	int key;
	node *parent;
	node *left;
	node *right;
	char color;
};
class RBtree
{
	node *root;
	node *q;
public:
	RBtree()
	{
		q = NULL;
		root = NULL;
	}
	void insert();
	void insert2(node *);
	void leftrotate(node *);
	void rightrotate(node *);
	void disp();
	void display(node *);
};
void RBtree::insert()
{

	char filename[100] = { "Text.txt" };	//Creating a text file to store the random numbers.
	ifstream fin;
	fin.open(filename);
	cout << "opened" << endl;
	while (!fin.eof())
	{
		int ch, i = 0;
		fin >> ch;
		node *p, *q;

		node *t = new node;
		t->key = ch;
		t->left = NULL;
		t->right = NULL;
		t->color = 'r';

		p = root;
		q = NULL;

		if (root == NULL)
		{
			root = t;
			t->parent = NULL;
		}

		else
		{
			while (p != NULL)
			{
				q = p;
				if (p->key < t->key)
					p = p->right;
				else
					p = p->left;
				n_ins = n_ins + 1;
			}

			t->parent = q;
			if (q->key < t->key)
				q->right = t;
			else
				q->left = t;
		}
		insert2(t);
	}
}
void RBtree::insert2(node *t)
{
	node *u;
	if (root == t)
	{
		t->color = 'b';
		return;
	}
	while (t->parent != NULL&&t->parent->color == 'r')
	{
		node *g = t->parent->parent;
		if (g->left == t->parent)
		{
			if (g->right != NULL)
			{
				u = g->right;
				if (u->color == 'r')
				{
					t->parent->color = 'b';
					u->color = 'b';
					g->color = 'r';
					t = g;
					n_splits = n_splits + 1;

				}
			}
			else
			{
				if (t->parent->right == t)
				{
					t = t->parent;
					leftrotate(t);
				}
				t->parent->color = 'b';
				g->color = 'r';
				rightrotate(g);
			}
		}
		else
		{
			if (g->left != NULL)
			{
				u = g->left;
				if (u->color == 'r')
				{
					t->parent->color = 'b';
					u->color = 'b';
					g->color = 'r';
					t = g;
				}
			}
			else
			{
				if (t->parent->left == t)
				{
					t = t->parent;
					rightrotate(t);
				}
				t->parent->color = 'b';
				g->color = 'r';
				leftrotate(g);
			}
		}
		root->color = 'b';
	}
}

void RBtree::leftrotate(node *p)
{
	l_rot = l_rot + 1;
	if (p->right == NULL)
		return;
	else
	{
		node *y = p->right;
		if (y->left != NULL)
		{
			p->right = y->left;
			y->left->parent = p;
		}
		else
			p->right = NULL;
		if (p->parent != NULL)
			y->parent = p->parent;
		if (p->parent == NULL)
			root = y;
		else
		{
			if (p == p->parent->left)
				p->parent->left = y;
			else
				p->parent->right = y;
		}
		y->left = p;
		p->parent = y;
	}
}
void RBtree::rightrotate(node *p)
{
	r_rot = r_rot + 1;
	if (p->left == NULL)
		return;
	else
	{
		node *y = p->left;
		if (y->right != NULL)
		{
			p->left = y->right;
			y->right->parent = p;
		}
		else
			p->left = NULL;
		if (p->parent != NULL)
			y->parent = p->parent;
		if (p->parent == NULL)
			root = y;
		else
		{
			if (p == p->parent->left)
				p->parent->left = y;
			else
				p->parent->right = y;
		}
		y->right = p;
		p->parent = y;
	}
}
void RBtree::disp()
{
	display(root);
}
void RBtree::display(node *p)
{
	if (root == NULL)
	{
		cout << "\nEmpty Tree.";
		return;
	}
	if (p != NULL)
	{

		cout << "\nThe  Key is: " << p->key;
		cout << "\n The Color of the node is : ";
		if (p->color == 'b')
			cout << "Black";
		else
			cout << "Red";
		if (p->parent != NULL)
			cout << "\n Parent: " << p->parent->key;
		else
			cout << "\n There is no parent of the node. "; if (p->right != NULL)
			cout << "\n Right Child: " << p->right->key;
			else
				cout << "\n There is no right child of the node. "; if (p->left != NULL)
			cout << "\n Left Child: " << p->left->key;
				else
					cout << "\n There is no left child of the node.  ";
		cout << endl; if (p->left)
		{
			cout << "\n\nLeft:\n"; display(p->left);
		}
		if (p->right)
		{
			cout << "\n\nRight:\n"; display(p->right);
		}

	}
}
int main()
{
	int ch, y = 0;
	RBtree obj;
	obj.insert();
	cout << "The Nodes supplied in the text file have been Inserted." << endl;
	cout << "No. of Left Rotations are:" << l_rot<<endl;
	cout << "No. of right Rotations are :" << r_rot<<endl;
	cout << "No of initial comparisons for insertion:" << n_ins<<endl;
	cout << "No. of Node Splits :" << n_splits << endl;
}