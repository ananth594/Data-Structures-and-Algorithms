#include<iostream>
#include<cstdlib>
using namespace std;


#include "BST_Sankarasubramanian.h"


BST::BST()	//Constructor

{

	root=NULL;
}


BST::node* BST::CreateLeaf(int key)	//Creating a new Node

{

	node* n=new node;
	n->key=key;
	n->left=n->right=NULL;
	return n; 

}

void BST::AddLeaf(int key)              // Function to call private function 
{

	addLeaf_p(key,root);

}


void BST::addLeaf_p(int key,node* ptr){
	
	if(root==NULL)
	{	
			
		root=CreateLeaf(key);

	}

	else if(key<ptr->key)  		//if key is less than the root value go to left subtree
	{
		if(ptr->left==NULL)
			{

			ptr->left=CreateLeaf(key);
			
			}
											
		
		else

			addLeaf_p(key,ptr->left);			


	}

	else if(key>ptr->key)
	{
		if(ptr->right==NULL)
			ptr->right=CreateLeaf(key);
											
		
		else
			
			addLeaf_p(key,ptr->right);


	}

	

}



BST::node* BST::ReturnNode_p(int key,node* ptr){

	
		if(ptr!=NULL)
		{

			if(ptr->key==key)

			{
				return ptr;
			}

			else if(key<ptr->key)

				return ReturnNode_p(key,ptr->left);
			else
				return ReturnNode_p(key,ptr->right);

		}
		
		else	
			{

			return NULL;	
		
			}
		
	
}



BST::node* BST::ReturnNode(int key)
{
	return ReturnNode_p(key,root);

}


int BST::rank(int key)
{

	return rank_p(key,root);	
	
}


int BST::rank_p(int key,node* ptr)	  //Function to find the rank of a given node
{
	if(ptr==NULL)
		return 0;
	if(key < ptr->key)
		return rank_p(key,ptr->left);
	else if(key > ptr->key)
		return 1+size_p(ptr->left) + rank_p(key,ptr->right);
	else
		return size_p(ptr->left);
}


int BST::Return_Key()
{
	if(root !=NULL)
	{
		return root->key;
	}

	else
		return 9999;

}

void BST::Print(int key)
{
	node* ptr=ReturnNode(key);

	if(ptr!=NULL)
	{			
		cout<<"The parent node is "<< ptr->key<<endl;

		ptr->left==NULL?
		cout<<"The left child is null \n":
		cout<<"The left child is: "<< ptr->left->key << endl;

		ptr->right==NULL?
		cout<<"The right child is null \n":
		cout<<"The right child is :"<< ptr->right->key << endl;
	}

	
		
	

}

int BST::size()
{
return size_p(root);

}

int BST::size_p(node* ptr)
{

	if(ptr==NULL)
		return 0;
	return 1+size_p(ptr->left)+size_p(ptr->right);
	

}

int BST::select(int rank)
	{
	
	return select_p(root,rank)->key;


	}

BST::node* BST::select_p(node* p,int rk)	//Function to perform select operation on a given node.
		
		{
	
			if(p!=NULL)
			{
			int t=size_p(p->left);
			if(t>rk)

			{
				return select_p(p->left,rk);
			}

			else if(t < rk)
			return select_p(p->right,rk-t-1);

			else if(t==rk)
			return p;

		}
		
		else
			{

			return NULL;	
		        
                        }
		

	}

