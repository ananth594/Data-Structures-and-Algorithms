// Name: Ananth Sankarasubramanian
// Course: Data Structures and Algorithm
// Assignment 3
// Date : 03/21/2017

#include<iostream>
#include<cstdlib>

using namespace std;

#include<fstream>
#include "BST_Sankarasubramanian.cpp"



int main()

{
	
char filename[100] = "hw3-q3-data.txt";	// reading the input file
int n;
int treeVals[1000000];

ifstream fin(filename);
int leaf_count=0;

  while(fin>>n){
 	treeVals[leaf_count]=n;
    leaf_count++;
  }

fin.close(); 

BST tree;
for(int i=0;i<leaf_count;i++)
{
	
tree.AddLeaf(treeVals[i]);	// Adding a node

}

cout<<endl;
cout << " The Rank of 15 is:  " << tree.rank(15) << endl; //Rank of 15
cout << " The Select of 9 is: " << tree.select(9) <<endl; //Rank of 9

return 0;

}
