class BST					// The entire BST is taken as a class
{

private:
	struct node				// Structure for a node
	{	
		int key;
		node* left;
		node* right;
		int count;
	};

	node* root;				// Private member functions to perform BST operations
	node* ReturnNode_p(int key, node* ptr);
	node* select_p(node* ptr, int rank);
	void addLeaf_p(int key,node*);
	int size_p(node* ptr);
	int rank_p(int key,node* ptr);

public:
						// Public member functions
 	BST();
	node* CreateLeaf(int key);
	node* ReturnNode(int key);
	int size();
	int rank(int key);
	int select(int rank);
	int Return_Key();
	void AddLeaf(int key);
	void Print(int key);
	

};
