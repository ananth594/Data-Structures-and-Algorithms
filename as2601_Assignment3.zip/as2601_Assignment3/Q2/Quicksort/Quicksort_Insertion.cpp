#include <iostream>
#include <fstream>
using namespace std;
#include <algorithm>
#include <time.h>

void swap(long int * a, long int *b)		//Function to Swap the numbers
{

	long int t = *a;
	*a = *b;
	*b =t;
}


long int partition(long int a[], int lo, int hi)	//Function o Partition the array
{	
		
	
	int i = lo;
	int j = hi + 1;

	while(true)
	{
		while(a[++i]<a[lo])
		{

			if(i==hi)
			break;
		}
		
		while(a[lo]<a[--j])
		{

			if( j == lo)
			break;

		}
		
		if(i >= j)
		break;
		
		swap(&a[i],&a[j]);		//Swapping the elements
		
		
	}
	
	swap(&a[lo],&a[j]);			// Swapping the element with the lowest element
	return j;	
		

		
 

}


long int medianof3(long int a[], int lo, int hi)
{
	int center = (lo + hi) / 2;
	if (a[lo] > a[center])
		swap(&a[lo], &a[center]);
	if (a[lo] > a[hi])
		swap(&a[lo], &a[hi]);
	if (a[center] > a[hi])
		swap(&a[center], &a[hi]);
	return center;
	}


void i_sort(long int a[], int lo, int hi)
{
	
	int i,key,j;
	int n= hi - lo +1;
	for(int i=1;i <n ;i++)
	{
	key = a[i];
	j=i-1;
	while(j>=0 && a[j] > key)
	{
		a[j+1] = a[j];
		j=j-1;
	}
	
	a[j+1]=key;

	}

}




void sort(long int a[], int lo , int hi, int &n_c)	//Function to sort the Elements
{
	
	if (lo<hi)
	{
	if(hi-lo +1 <= 10)
	{
		i_sort(a,lo,hi);
	}
	else
	{	
	int median = medianof3(a, lo, hi);
	swap(&a[lo],&a[median]);


	int p = partition(a, lo, hi);
	sort(a,lo,p-1,n_c);				//Recursively calling the function
	sort(a,p+1,hi,n_c);
		
	}
	}	

}



int main()
{
	
	
	char filename[100] = { "/home/ananth/Downloads/hw2-dataset/random.txt" };	// Creating a text file to store random numbers generated.

	const long int N= 6;	// Change this value to find the time for different number of elements.
	static long int   a[N] = { 0 };
	static long int aux[N] = { 0 };
	int n_c = 0;
	
	
	srand (1);	
	
	ofstream fout1;
	fout1.open(filename);

	for(int k = 0;k<N ;k++)		// Creating N Random numbers
	{

	a[k] = rand()%N + 1;
	fout1<<a[k]<<endl;
		
	}

      	random_shuffle(&a[0],&a[N-1]);	// Suffling the Array for optimisation
	
	clock_t start = clock();	//Starting the clock 
	sort(a, 0,N-1,n_c );		//Sorting the numbers
	double duration = (double)(clock() - start)/CLOCKS_PER_SEC;// end of clock

	char filename2[100] = { "/home/ananth/Downloads/hw2-dataset/Routput0.txt" };
	ofstream fout2;
	fout2.open(filename2);
	

	for (int i = 0; i < N; i++)
	{
		fout2 << a[i]<<endl;
		
	}
	
	
	
	cout<<"The No. of Charaters in the file are : "<<N<<endl;
	cout<<"The Runtime is : "<< duration<<endl;
	

	return 0;
}
