#include <iostream>
#include <fstream>
using namespace std;
#include <time.h>
#include <algorithm>


void merge(long int a[], long int aux[],int lo, int mid, int hi,int &n_c)	//Function to merge the arrays.
{	
		
	

	for (int k = lo; k <= hi; k++)
		aux[k] = a[k];
	
	int i = lo;
	int j = mid + 1;

	for (int k = lo; k <= hi; k++)		//Different conditions considered to decide which element to store first in the merged array
	{
		if (i > mid)
			a[k] = aux[j++];

		else if (j > hi)
			a[k] = aux[i++];

		else if (aux[j] < aux[i])
			a[k] = aux[j++];

		else
			a[k] = aux[i++];
		
		n_c = n_c + 1;			//To determine the number of comparisons.

	}

 

}

void i_sort(long int a[], int lo, int hi)			//Function to perform Insertion Sort 
{
	
	int i,key,j;
	int n= hi - lo +1;
	for(int i=1;i <n ;i++)
	{
	key = a[i];
	j=i-1;
	while(j>=0 && a[j] > key)
	{
		a[j+1] = a[j];
		j=j-1;
	}
	
	a[j+1]=key;

	}
}


void sort(long int a[],long int aux[], int lo , int hi, int &n_c)		//Function to sort the array
{
	if (lo<hi)
	{
	if(hi-lo +1 <= 10)
	{
		i_sort(a,lo,hi);
	}
	else
	{
	

	int mid = lo + (hi - lo) / 2;
	sort(a,aux,lo, mid,n_c);
	sort(a,aux,mid + 1, hi, n_c);
	merge(a,aux,lo, mid, hi, n_c);
	
	}
	
	}	

}



 


int main()
{
	
	
	char filename[100] = { "/home/ananth/Downloads/hw2-dataset/random.txt" };	// Creating a text file to store random numbers generated.
	const long int N= 1000000;	// Change this value to find the time for different number of elements.
	static long int   a[N] = { 0 };
	static long int aux[N] = { 0 };
	int n_c = 0;
	
	
	srand (2);	
	
	ofstream fout1;
	fout1.open(filename);

	for(int k = 0;k<N ;k++)		// Creating N Random numbers
	{

	a[k] = rand()%N + 1;
	fout1<<a[k]<<endl;
		
	}	

	clock_t start = clock();	
	sort(a, aux, 0, N-1,n_c );	//Calling the sorting function
	double duration = (double)(clock() - start)/CLOCKS_PER_SEC;// end of clock

	char filename2[100] = { "/home/ananth/Downloads/hw2-dataset/output0.txt" };
	ofstream fout;
	fout.open(filename2);

	for (int i = 0; i < N; i++)
	{
		fout << a[i]<<endl;	//Storing the sorted array in a text file.
		
	}
	
	fout << "No. of Comparisons :"<<n_c;

	cout<<"The No. of Charaters in the file are : "<< N<<endl;
	cout<<"The Runtime is : "<< duration<<endl;

	return 0;
}
